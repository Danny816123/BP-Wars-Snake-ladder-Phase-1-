package ir.sharif.math.bp99_1.snake_and_ladder;


import ir.sharif.math.bp99_1.snake_and_ladder.logic.LogicalAgent;

public class Main {

    public static void main(String[] args) {
        LogicalAgent logicalAgent = new LogicalAgent();
        logicalAgent.initialize();
    }
}